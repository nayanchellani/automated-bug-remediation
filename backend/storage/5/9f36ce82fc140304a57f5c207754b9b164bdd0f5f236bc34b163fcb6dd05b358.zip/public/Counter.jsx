const { useState } = React

async function post(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {}),
  })
  if (!res.ok) {
    const data = await res.json().catch(() => ({}))
    throw new Error(data.message || `Request failed (${res.status})`)
  }
  return res.json()
}

function Counter() {
  const [count, setCount] = useState(0)
  const [status, setStatus] = useState({ text: 'Click + past 5 to trigger a server error.', error: false })

  const run = async (fn) => {
    try {
      await fn()
    } catch (err) {
      setStatus({ text: err.message, error: true })
    }
  }

  const increment = () =>
    run(async () => {
      const next = count + 1
      const data = await post('/api/counter', { value: next })
      setCount(data.value)
      setStatus({ text: 'OK', error: false })
    })

  const decrement = () => setCount((c) => c - 1)
  const reset = () => {
    setCount(0)
    setStatus({ text: 'Reset.', error: false })
  }
  const crash = () => run(() => post('/api/counter/crash'))

  return (
    <div className="counter">
      <div>Triage demo counter</div>
      <div className="value">{count}</div>
      <div className="row">
        <button onClick={decrement} className="outline">-</button>
        <button onClick={increment}>+</button>
        <button onClick={reset} className="outline">Reset</button>
        <button onClick={crash} className="danger">Crash server</button>
      </div>
      <div className={`status${status.error ? ' error' : ''}`}>{status.text}</div>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<Counter />)
